'use client';
import { MotionConfig } from 'framer-motion';
import { usePathname } from 'next/navigation';
import { useEffect, useRef, type ReactNode } from 'react';
import { NoteEditorSheet } from '@/components/forms/NoteEditor';
import { RemindersSheet } from '@/components/forms/RemindersSheet';
import { TaskFormSheet } from '@/components/forms/TaskForm';
import { TransactionFormSheet } from '@/components/forms/TransactionForm';
import { BottomNav } from '@/components/navigation/BottomNav';
import { QuickAddSheet } from '@/components/navigation/QuickAddSheet';
import { ToastHost } from '@/components/ui/Toast';
import { useMeetings, useSettings, useTasks } from '@/hooks/useData';
import { useNow } from '@/hooks/useNow';
import { registerServiceWorker } from '@/pwa/register';
import { dueReminders } from '@/services/recurrence';
import { useUI } from '@/stores/ui';

function useTheme() {
  const { theme } = useSettings();
  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => {
      const dark = theme === 'dark' || (theme === 'system' && mq.matches);
      document.documentElement.classList.toggle('dark', dark);
      try {
        localStorage.setItem('myagenda-theme', theme); // UI preference only, no user data
      } catch {}
    };
    apply();
    mq.addEventListener('change', apply);
    return () => mq.removeEventListener('change', apply);
  }, [theme]);
}

/** In-app reminders: shows a toast (and a system notification if permitted) once per occurrence. */
function useReminderTicker() {
  const tasks = useTasks();
  const meetings = useMeetings();
  const now = useNow(30_000);
  const shown = useRef(new Set<string>());
  useEffect(() => {
    for (const o of dueReminders(tasks, meetings, now)) {
      const key = `${o.kind}:${o.id}:${o.date}`;
      if (shown.current.has(key)) continue;
      shown.current.add(key);
      const msg = `⏰ ${o.startTime} — ${o.title}`;
      useUI.getState().showToast({ message: msg, tone: 'warn' });
      if ('Notification' in window && Notification.permission === 'granted') {
        try {
          new Notification('MyAgenda', { body: msg, tag: key });
        } catch {}
      }
    }
  }, [tasks, meetings, now]);
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const hideNav = pathname.startsWith('/settings');
  useTheme();
  useReminderTicker();

  useEffect(() => {
    registerServiceWorker();
    if (navigator.storage?.persist) navigator.storage.persist().catch(() => {});
  }, []);

  return (
    <MotionConfig reducedMotion="user">
      <div className="mx-auto min-h-[100dvh] w-full max-w-[480px] overflow-x-hidden">
        <main className={hideNav ? '' : 'pb-[calc(84px+env(safe-area-inset-bottom))]'}>{children}</main>
      </div>
      {!hideNav && <BottomNav />}
      <QuickAddSheet />
      <TaskFormSheet />
      <TransactionFormSheet />
      <NoteEditorSheet />
      <RemindersSheet />
      <ToastHost />
    </MotionConfig>
  );
}
