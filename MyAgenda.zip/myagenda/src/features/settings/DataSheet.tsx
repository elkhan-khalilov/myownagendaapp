'use client';
import { Download, FlaskConical, RotateCcw, Upload } from 'lucide-react';
import { useRef, useState } from 'react';
import { Button } from '@/components/ui/controls';
import { Sheet } from '@/components/ui/Sheet';
import { buildBackup, downloadJSON, importBackup, validateBackup } from '@/services/backup';
import { useUI } from '@/stores/ui';
import { toKey } from '@/utils/date';

export function DataSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const showToast = useUI((s) => s.showToast);
  const fileRef = useRef<HTMLInputElement>(null);
  const [mode, setMode] = useState<'merge' | 'replace'>('merge');
  const [busy, setBusy] = useState(false);

  async function exportAll() {
    const backup = await buildBackup();
    downloadJSON(backup, `myagenda-backup-${toKey(new Date())}.json`);
    showToast({ message: 'Ehtiyat nüsxə yükləndi' });
  }

  function pick(m: 'merge' | 'replace') {
    setMode(m);
    fileRef.current?.click();
  }

  async function onFile(file: File | undefined) {
    if (!file) return;
    setBusy(true);
    try {
      const json = JSON.parse(await file.text());
      const res = validateBackup(json);
      if (!res.ok) throw new Error(res.error);
      if (mode === 'replace' && !window.confirm('Bütün cari məlumatlar ehtiyat nüsxə ilə əvəz olunacaq. Davam edilsin?')) return;
      const n = await importBackup(res.backup, mode);
      showToast({ message: `${n} qeyd ${mode === 'replace' ? 'bərpa edildi' : 'idxal edildi'}` });
      onClose();
    } catch (e) {
      showToast({ message: e instanceof SyntaxError ? 'Fayl JSON formatında deyil' : (e as Error).message, tone: 'error' });
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  }

  return (
    <Sheet open={open} onClose={onClose} title="Sinxronizasiya və məlumatlar">
      <div className="space-y-3 pb-2 pt-1">
        <div className="rounded-2xl bg-p-yellow p-4 text-[13.5px]">
          Məlumatlar yalnız bu cihazda (brauzer yaddaşında) saxlanılır. Bulud sinxronizasiyası hələ yoxdur — backend (FastAPI +
          PostgreSQL) qoşulanda əlavə olunacaq. iOS brauzer məlumatlarını silə bilər, ona görə vaxtaşırı ehtiyat nüsxə çıxarın.
        </div>
        <Button className="w-full" onClick={exportAll}>
          <Download size={18} /> Ehtiyat nüsxə çıxar (JSON)
        </Button>
        <Button variant="soft" className="w-full" onClick={() => pick('merge')} disabled={busy}>
          <Upload size={18} /> İdxal et (birləşdir)
        </Button>
        <Button variant="danger" className="w-full" onClick={() => pick('replace')} disabled={busy}>
          <RotateCcw size={18} /> Ehtiyat nüsxədən bərpa et
        </Button>
        <p className="px-1 text-xs text-muted">
          İdxal zamanı eyni ID-li qeydlər yenilənir, təkrarlanmır. Bərpa cari məlumatları silib ehtiyat nüsxəni yazır.
        </p>
        {process.env.NODE_ENV === 'development' && <DemoButton />}
        <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={(e) => void onFile(e.target.files?.[0])} />
      </div>
    </Sheet>
  );
}

function DemoButton() {
  const showToast = useUI((s) => s.showToast);
  return (
    <Button
      variant="ghost"
      className="w-full border border-dashed border-line"
      onClick={async () => {
        const { loadDemoData } = await import('@/services/demoData');
        await loadDemoData();
        showToast({ message: 'Demo məlumat yükləndi (dev)' });
      }}
    >
      <FlaskConical size={18} /> Demo məlumat yüklə (yalnız development)
    </Button>
  );
}
