'use client';
import { create } from 'zustand';
import type { NoteCategory, TransactionType } from '@/types';

export type SheetState =
  | { type: 'task'; id?: string; kind?: 'task' | 'meeting'; date?: string; occurrenceDate?: string }
  | { type: 'transaction'; id?: string; txType?: TransactionType }
  | { type: 'note'; id?: string; category?: NoteCategory }
  | { type: 'reminders' }
  | null;

export interface Toast {
  id: number;
  message: string;
  actionLabel?: string;
  action?: () => void;
  tone?: 'default' | 'error' | 'warn';
}

interface UIState {
  quickAddOpen: boolean;
  setQuickAdd: (open: boolean) => void;
  sheet: SheetState;
  openSheet: (s: SheetState) => void;
  closeSheet: () => void;
  toast: Toast | null;
  showToast: (t: Omit<Toast, 'id'>) => void;
  dismissToast: () => void;
}

export const useUI = create<UIState>((set) => ({
  quickAddOpen: false,
  setQuickAdd: (quickAddOpen) => set({ quickAddOpen }),
  sheet: null,
  openSheet: (sheet) => set({ sheet, quickAddOpen: false }),
  closeSheet: () => set({ sheet: null }),
  toast: null,
  showToast: (t) => set({ toast: { ...t, id: Date.now() } }),
  dismissToast: () => set({ toast: null }),
}));

/** Show an undo toast after a deletion */
export function undoToast(message: string, undo: () => Promise<unknown>) {
  useUI.getState().showToast({ message, actionLabel: 'Geri qaytar', action: () => void undo() });
}
