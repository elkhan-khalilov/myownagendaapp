import type { Note } from '@/types';

export type NoteSort = 'updated' | 'created' | 'title';

/** Pinned notes first, then by the selected sort key. */
export function sortNotes(notes: Note[], sort: NoteSort): Note[] {
  return [...notes].sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    if (sort === 'title') return (a.title || '').localeCompare(b.title || '', 'az');
    const k = sort === 'created' ? 'createdAt' : 'updatedAt';
    return a[k] < b[k] ? 1 : -1;
  });
}
