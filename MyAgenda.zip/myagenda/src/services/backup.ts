import type { MyAgendaDB } from '@/db/schema';
import { getDB } from '@/db/schema';

export const BACKUP_FORMAT = 'myagenda-backup';
export const BACKUP_VERSION = 1;

export const TABLES = [
  'tasks',
  'meetings',
  'notes',
  'transactions',
  'transactionCategories',
  'budgets',
  'financialAccounts',
  'userSettings',
] as const;
export type TableName = (typeof TABLES)[number];

export interface BackupFile {
  format: typeof BACKUP_FORMAT;
  version: number;
  exportedAt: string;
  data: Record<TableName, Record<string, unknown>[]>;
}

export async function buildBackup(db: MyAgendaDB = getDB()): Promise<BackupFile> {
  const data = {} as BackupFile['data'];
  for (const t of TABLES) data[t] = (await db.table(t).toArray()) as Record<string, unknown>[];
  return { format: BACKUP_FORMAT, version: BACKUP_VERSION, exportedAt: new Date().toISOString(), data };
}

const REQUIRED: Partial<Record<TableName, string[]>> = {
  tasks: ['id', 'title', 'date'],
  meetings: ['id', 'title', 'date', 'startTime', 'endTime'],
  notes: ['id', 'category'],
  transactions: ['id', 'type', 'amount', 'categoryId', 'date'],
  transactionCategories: ['id', 'type', 'name'],
  budgets: ['id', 'categoryId', 'limit'],
  financialAccounts: ['id', 'name'],
  userSettings: ['id'],
};

export function validateBackup(raw: unknown): { ok: true; backup: BackupFile } | { ok: false; error: string } {
  if (!raw || typeof raw !== 'object') return { ok: false, error: 'Fayl JSON obyekti deyil' };
  const b = raw as Partial<BackupFile>;
  if (b.format !== BACKUP_FORMAT) return { ok: false, error: 'Bu MyAgenda ehtiyat faylı deyil' };
  if (typeof b.version !== 'number' || b.version > BACKUP_VERSION)
    return { ok: false, error: `Dəstəklənməyən versiya: ${String(b.version)}` };
  if (!b.data || typeof b.data !== 'object') return { ok: false, error: 'Məlumat bölməsi yoxdur' };
  for (const t of TABLES) {
    const rows = (b.data as Record<string, unknown>)[t];
    if (rows === undefined) continue;
    if (!Array.isArray(rows)) return { ok: false, error: `"${t}" massiv deyil` };
    for (const row of rows) {
      if (!row || typeof row !== 'object') return { ok: false, error: `"${t}" daxilində yanlış qeyd` };
      for (const f of REQUIRED[t] ?? []) {
        if ((row as Record<string, unknown>)[f] === undefined)
          return { ok: false, error: `"${t}" qeydində "${f}" sahəsi yoxdur` };
      }
      if (t === 'transactions') {
        const amt = (row as { amount: unknown }).amount;
        if (typeof amt !== 'number' || !Number.isInteger(amt) || amt <= 0)
          return { ok: false, error: 'Əməliyyat məbləği tam ədəd (qəpik) olmalıdır' };
      }
    }
  }
  return { ok: true, backup: b as BackupFile };
}

/**
 * Import a validated backup. Records are upserted by id, so importing the same file twice
 * never creates duplicates. mode "replace" clears existing data first (restore).
 */
export async function importBackup(backup: BackupFile, mode: 'merge' | 'replace', db: MyAgendaDB = getDB()) {
  let count = 0;
  await db.transaction('rw', TABLES.map((t) => db.table(t)), async () => {
    for (const t of TABLES) {
      const rows = backup.data[t];
      if (mode === 'replace' && t !== 'userSettings') await db.table(t).clear();
      if (!rows?.length) continue;
      await db.table(t).bulkPut(rows);
      count += rows.length;
    }
  });
  return count;
}

export function downloadJSON(obj: unknown, filename: string) {
  const blob = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
