export function registerServiceWorker() {
  if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return;
  if (process.env.NODE_ENV !== 'production') return;
  const swUrl = `${process.env.NEXT_PUBLIC_BASE_PATH ?? ''}/sw.js`;
  navigator.serviceWorker.register(swUrl).catch((e) => console.warn('[pwa] SW registration failed', e));
}
