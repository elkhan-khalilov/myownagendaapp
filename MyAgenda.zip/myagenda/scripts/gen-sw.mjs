// Post-build: inject the list of hashed build assets + a build version into out/sw.js
import { createHash } from 'node:crypto';
import { readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { join, relative } from 'node:path';

const OUT = 'out';
const walk = (dir) => readdirSync(dir).flatMap((f) => {
  const p = join(dir, f);
  return statSync(p).isDirectory() ? walk(p) : [p];
});
const assets = walk(join(OUT, '_next', 'static')).map((p) => '/' + relative(OUT, p).split('\\').join('/'));
const hash = createHash('sha256').update(assets.join('|')).digest('hex').slice(0, 10);
const swPath = join(OUT, 'sw.js');
const sw = readFileSync(swPath, 'utf8')
  .replace("'__BUILD_VERSION__'", JSON.stringify(hash))
  .replace('[] /*__PRECACHE__*/', JSON.stringify(assets));
writeFileSync(swPath, sw);
console.log(`[gen-sw] ${assets.length} assets precached, version ${hash}`);
