# MyAgenda — Agenda · Büdcə · Notlar

An offline-first Progressive Web App for personal agenda, budget and notes, optimized for iPhone 13 Pro Max (428×926) and installable to the iOS Home Screen. UI language: Azerbaijani.

## Stack

Next.js 15 (App Router, static export) · React 19 · TypeScript · Tailwind CSS · Dexie.js (IndexedDB) · Zustand · Recharts (lazy-loaded) · Framer Motion · date-fns · Lucide · Vitest + Testing Library.

UI primitives (sheet, segmented control, inputs, chips) are hand-written in `src/components/ui` in the shadcn style, so there is no Radix dependency or CLI step.

## Quick start

```bash
npm install
npm run dev        # http://localhost:3000
npm test           # 29 unit + integration tests
npm run build      # static export to ./out + service-worker precache injection
npm start          # serve ./out locally
```

In **development** only, Settings → Sinxronizasiya has a "Demo məlumat yüklə" button. It is not rendered in production builds, so production starts empty.

## Features

| Screen | What works |
|---|---|
| Əsas | Greeting + Azerbaijani date, reminder bell (badge when a reminder is due), settings link, live summary cards, today's tasks with inline completion, budget ring (spent vs. monthly limit), next 3 upcoming events |
| Agenda | Gün / Həftə / Ay views, month & week navigation, date strip, timeline with category colours, filters (status + category), search, task & meeting CRUD, recurring (daily/weekly/monthly, optional end date) with per-occurrence completion, "+1 gün" reschedule, time validation, reminders |
| Büdcə | Month selector, Qalıq/Gəlir/Xərc cards, expense donut, 6-month income/expense bars, total + per-category limits with 80% warning / overspend alerts, transactions CRUD, search, type/category/date filters |
| Notlar | Search, sort (updated/created/title), category chips, pinned-only filter, pastel cards, pin/edit/delete menu, full-screen editor with debounced auto-save, multiline |
| Parametrlər | Dark navy screen, profile (name, email, currency), navigation, Hesabatlar (monthly report), Kateqoriyalar (add/edit/delete; deletion blocked if used), Hədəflər (monthly limits), Sinxronizasiya (versioned JSON export / merge import / restore), Light/Dark/System theme |
| Quick Add (+) | Yeni tapşırıq, Yeni görüş, Gəlir, Xərc, Yeni qeyd: all functional |

Deletions show an **undo** toast.

## Architecture

```
src/
  app/            routes (thin pages → features)
  features/       screen components (home, agenda, finance, notes, settings)
  components/     layout, navigation, cards, charts, forms, ui
  db/             Dexie schema (v1 → v2 migration) + seed
  repositories/   CRUD layer (REST-shaped: list/get/create/update/remove)
  services/       pure business logic: finance, recurrence, backup, notes
  hooks/ stores/  live queries (dexie-react-hooks), Zustand UI state
  utils/          money (integer minor units), dates (az locale), ids
  pwa/            service-worker registration
public/           manifest, sw.js, icons, iOS splash
scripts/gen-sw.mjs  post-build precache injection
tests/
```

**Money** is stored as integer qəpik (`12,50 ₼ → 1250`). Parsing is string-based (no float multiplication), all sums are integer, percentages use the largest-remainder method, and backup import rejects non-integer amounts.

**Backend readiness:** UI talks to `repositories/*`, whose methods map 1:1 to REST endpoints (`GET /tasks`, `POST /tasks`, `PATCH /tasks/{id}`, `DELETE /tasks/{id}` …). To add FastAPI + PostgreSQL, implement the same interface over `fetch`, keep Dexie as the offline cache and add a sync queue. All records already have UUIDs and `createdAt`/`updatedAt` for conflict resolution.

## PWA & iOS notes (honest limitations)

- The service worker caches **only the app shell** (HTML, JS, CSS, icons). User data lives in IndexedDB and is never written to Cache Storage.
- After the first online load, the app works fully offline (verified in Chromium with network disabled).
- **Reminders** are in-app: a toast appears, plus a system notification if permission was granted, **while the app is open**. Scheduled background notifications on iOS require a Home Screen install (iOS 16.4+), permission and a Web Push backend. These are not implemented yet.
- **No iCloud sync, no Face ID.** Neither is available to an offline PWA. Data stays on this device; use Sinxronizasiya → export regularly, because iOS may evict website storage. The app calls `navigator.storage.persist()` to reduce that risk.
- Status bar style is `default` (dark text on light), which keeps the light screens readable.

## Testing

`npm test` runs 29 tests: money parsing/formatting, finance calculations & budget levels, recurrence & reminders, IndexedDB CRUD for tasks/meetings/transactions/notes (fake-indexeddb), undo/restore, budget limits, export → import without duplicates, backup validation, restore, and UI components (navigation, ring).

Verified in headless Chromium at 428×926: all screens render, no horizontal overflow, no console errors, offline reload works.

**Not verified:** real iOS Safari and Home Screen standalone mode, because no iOS device or simulator was available in the build environment. Playwright end-to-end specs are not included in this repo; the browser checks were run ad hoc.

See **DEPLOY.md** for deployment and iPhone installation.
