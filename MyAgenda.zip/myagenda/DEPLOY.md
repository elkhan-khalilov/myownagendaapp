# Deploying MyAgenda

The build is a fully static site in `./out`. Any HTTPS static host works. HTTPS is required for the service worker and Home Screen install.

## Option A — Vercel (simplest)

```bash
npm i -g vercel
vercel            # framework auto-detected: Next.js
vercel --prod
```

## Option B — Netlify

- Build command: `npm run build`
- Publish directory: `out`

## Option C — Your own server (nginx)

```bash
npm ci && npm run build
rsync -a out/ user@server:/var/www/myagenda/
```

```nginx
server {
  server_name agenda.example.az;
  root /var/www/myagenda;
  location / { try_files $uri $uri/ $uri.html /index.html; }
  location = /sw.js { add_header Cache-Control "no-cache"; }
  location /_next/static/ { add_header Cache-Control "public, max-age=31536000, immutable"; }
  types { application/manifest+json webmanifest; }
  # TLS via certbot: certbot --nginx -d agenda.example.az
}
```

Serve `sw.js` with `no-cache` so updates reach users. Each build gets a new cache version automatically (see `scripts/gen-sw.mjs`).

## Install on iPhone

1. Open the HTTPS URL in **Safari**.
2. Tap **Share** (□↑).
3. Choose **Add to Home Screen** → **Add**.
4. Launch **MyAgenda** from the Home Screen. It opens standalone, without Safari UI.
5. Open the app once while online. After that it works offline.

Data is stored per installation: the Home Screen app and Safari tabs have separate storage. Use Parametrlər → Sinxronizasiya → *Ehtiyat nüsxə çıxar* to back up.

## Updating

Deploy a new build. The installed app picks up the new service worker on its next launch and refreshes the cached shell. User data in IndexedDB is untouched. Schema changes go through Dexie version migrations in `src/db/schema.ts`.
